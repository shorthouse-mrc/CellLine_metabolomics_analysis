# PID of current job: 1003846
mSet<-InitDataObjects("conc", "pathora", FALSE)
cmpd.vec<-c("Pyruvaldehyde","Malondialdehyde","Fumaric acid","Maleic acid","L-Malic acid","Malic acid","O-Phosphoethanolamine","2,5-Furandicarboxylic acid","L-Fucose","Rhamnose","1,5-Anhydrosorbitol","Beta-D-Fucose","L-Rhamnulose","2-Deoxygalactopyranose","Galactitol","Sorbitol","Mannitol","L-Iditol","Epinephrine","Normetanephrine","Methylnoradrenaline","Mannitol 1-phosphate","Sorbitol-6-phosphate","N-Acetylneuraminic acid","N-Acetyl-a-neuraminic acid","N-Oleoylethanolamine","Stearoylethanolamide","N,N-Dimethylsphingosine","CDP-Ethanolamine","LysoPC(15:0)","LysoPE(0:0/18:0)","LysoPE(18:0/0:0)","SM(d18:1/14:0)","PE(20:2(11Z,14Z)/P-18:1(11Z))","PE(20:2(11Z,14Z)/P-18:1(9Z))","PE(20:3(5Z,8Z,11Z)/P-18:0)","PE(20:3(8Z,11Z,14Z)/P-18:0)","PE(P-18:0/20:3(5Z,8Z,11Z))","PE(P-18:0/20:3(8Z,11Z,14Z))","PE(P-18:1(11Z)/20:2(11Z,14Z))","PE(P-18:1(9Z)/20:2(11Z,14Z))","Malonyl-CoA","PIP(16:0/20:2(11Z,14Z))","PIP(18:0/18:2(9Z,12Z))","PIP(18:1(11Z)/18:1(11Z))","PIP(18:1(11Z)/18:1(9Z))","PIP(18:1(9Z)/18:1(11Z))","PIP(18:1(9Z)/18:1(9Z))","PIP(18:2(9Z,12Z)/18:0)","PIP(20:2(11Z,14Z)/16:0)","Galabiosylceramide (d18:1/22:0)","Lactosylceramide (d18:1/22:0)")
mSet<-Setup.MapData(mSet, cmpd.vec);
mSet<-CrossReferencing(mSet, "name");
mSet<-CreateMappingResultTable(mSet)
mSet<-SetKEGG.PathLib(mSet, "hsa", "current")
mSet<-SetMetabolomeFilter(mSet, F);
mSet<-CalculateOraScore(mSet, "rbc", "hyperg")
mSet<-PlotPathSummary(mSet, F, "path_view_0_", "png", 72, width=NA)
